<?php
include 'db.php';
if (!isset($_SESSION['user'])) header("Location: login1.php");

$from = $_SESSION['user']['id'];
$to = $_POST['to'];
$amount = floatval($_POST['amount']);

$conn->begin_transaction();
try {
    $fromBalance = $conn->query("SELECT balance FROM customers WHERE id=$from")->fetch_assoc()['balance'];
    if ($fromBalance >= $amount && $amount > 0) {
        $conn->query("UPDATE customers SET balance = balance - $amount WHERE id = $from");
        $conn->query("UPDATE customers SET balance = balance + $amount WHERE id = $to");
        $conn->query("INSERT INTO transactions (sender_id, receiver_id, amount) VALUES ($from, $to, $amount)");
        $conn->commit();
        $_SESSION['user'] = $conn->query("SELECT * FROM customers WHERE id=$from")->fetch_assoc();
        header("Location: d.php?success=1");
    } else {
        throw new Exception("Insufficient funds or invalid amount");
    }
} catch (Exception $e) {
    $conn->rollback();
    header("Location: d.php?error=1");
}
?>
