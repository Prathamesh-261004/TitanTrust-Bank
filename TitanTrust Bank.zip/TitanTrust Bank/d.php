<?php include 'db.php';
if (!isset($_SESSION['user'])) header("Location: login1.php");

$user = $_SESSION['user'];
$res = $conn->query("SELECT * FROM customers WHERE id != {$user['id']}");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Dashboard - <?= htmlspecialchars($user['name']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-4">
    <div class="d-flex justify-content-between mb-4">
        <h4>Welcome, <?= htmlspecialchars($user['name']); ?></h4>
        <a href="logout.php" class="btn btn-danger">Logout</a>
    </div>
    <div class="card mb-4">
        <div class="card-body">
            <p><strong>Email:</strong> <?= $user['email']; ?></p>
            <p><strong>Balance:</strong> ₹<?= number_format($user['balance'], 2); ?></p>
        </div>
    </div>
    <h5>Transfer Money</h5>
    <?php
    if (isset($_GET['success'])) echo "<div class='alert alert-success'>Transfer successful.</div>";
    if (isset($_GET['error'])) echo "<div class='alert alert-danger'>Error during transfer.</div>";
    ?>
    <form method="post" action="transfer.php">
        <div class="mb-3">
            <label>Recipient:</label>
            <select name="to" class="form-select" required>
                <?php while ($row = $res->fetch_assoc()): ?>
                    <option value="<?= $row['id']; ?>"><?= htmlspecialchars($row['name']); ?> - ₹<?= number_format($row['balance'], 2); ?></option>
                <?php endwhile; ?>
            </select>
        </div>
        <input type="number" step="0.01" name="amount" class="form-control mb-3" placeholder="Amount (₹)" required>
        <button class="btn btn-success">Send</button>
        
    </form>
    
    <style>
    #backButton {
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 10px 15px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
      transition: background-color 0.3s;
    }

    #backButton:hover {
      background-color: #45a049;
    }
  </style>
</head>
<body>

  <button id="backButton" onclick="goBack()">🔙 Back</button>

  <script>
    function goBack() {
      window.history.back();
    }
  </script>

</div>
</body>
</html>
