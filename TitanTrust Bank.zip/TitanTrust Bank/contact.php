<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TitanTrust Bank - Contact Us</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Styles -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
        }

        .navbar {
            background-color: #00274D;
            padding: 15px 0;
        }

        .navbar-brand {
            font-size: 1.8rem;
            font-weight: bold;
            color: #fff;
        }

        .nav-link {
            color: #fff !important;
            font-weight: 500;
            margin-right: 15px;
        }

        .hero-section {
            background: linear-gradient(to right, #004080, #00274D);
            color: white;
            padding: 80px 20px;
            text-align: center;
        }

        .hero-section h1 {
            font-size: 2.5rem;
            font-weight: bold;
        }

        .contact-container {
            background: #ffffff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .btn-custom {
            background-color: #004080;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
        }

        .btn-custom:hover {
            background-color: #00274D;
        }

        .footer {
            background-color: #00274D;
            color: white;
            padding: 20px 0;
            text-align: center;
            margin-top: 40px;
        }

        .footer a {
            color: #f8f9fa;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="#">TitanTrust Bank</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
          
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <h1>Contact TitanTrust Bank</h1>
        <p>Your trusted partner in financial services. Reach out to us for assistance.</p>
    </section>

    <!-- Contact Form -->
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-6 contact-container">
                <h3 class="text-center">Get in Touch</h3>
                <p class="text-center text-muted">We’re here to help. Fill out the form, and our team will reach out to you.</p>

                <form>
                    <div class="mb-3">
                        <label for="name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="name" placeholder="Enter your name" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" class="form-control" id="email" placeholder="Enter your email" required>
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label">Your Message</label>
                        <textarea class="form-control" id="message" rows="5" placeholder="Write your message here" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-custom w-100">Send Message</button>
                </form>
            </div>
        </div>
    </div><style>
    #backButton {
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 10px 15px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
      transition: background-color 0.3s;
    }

    #backButton:hover {
      background-color: #45a049;
    }
  </style>
</head>
<body>

  <button id="backButton" onclick="goBack()">🔙 Back</button>

  <script>
    function goBack() {
      window.history.back();
    }
  </script>


    <!-- Footer -->
    <footer class="footer">
        <p>&copy; 2025 TitanTrust Bank | All Rights Reserved</p>
        <p>Email: support@foundationbank.com | Phone: +91-9876543210</p>
        <p><a href="#">Privacy Policy</a> | <a href="#">Terms & Conditions</a></p>
    </footer>

    <!-- Bootstrap Bundle with Popper -->
     
    <script src="https://cdn.botpress.cloud/webchat/v2.2/inject.js"></script>
<script src="https://files.bpcontent.cloud/2025/01/25/11/20250125113618-DP2RJ8FU.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>
