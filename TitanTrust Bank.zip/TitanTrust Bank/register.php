<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register - Bank</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #dff9fb, #c7ecee);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .register-card {
            animation: fadeIn 1s ease-in-out;
            max-width: 450px;
            margin: auto;
            margin-top: 60px;
            background-color: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .form-control:focus {
            box-shadow: 0 0 8px rgba(34, 167, 240, 0.5);
            border-color: #22a6b3;
        }
        .btn-primary {
            background-color: #22a6b3;
            border: none;
        }
        .btn-primary:hover {
            background-color: #1e90a3;
        }
        #backButton {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 10px 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            transition: background-color 0.3s;
        }
        #backButton:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
<div class="register-card">
    <h3 class="mb-4 text-center">🔐 Create Account</h3>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $conn->real_escape_string($_POST['name']);
        $email = $conn->real_escape_string($_POST['email']);
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
        $balance = 1000;

        $sql = "INSERT INTO customers (name, email, password, balance) VALUES ('$name', '$email', '$password', $balance)";
        if ($conn->query($sql)) {
            echo "<div class='alert alert-success'>Registered successfully. <a href='login1.php'>Login now</a>.</div>";
        } else {
            echo "<div class='alert alert-danger'>Email already exists or error occurred.</div>";
        }
    }
    ?>
    <form method="post">
        <input name="name" class="form-control mb-3" placeholder="Name" required>
        <input name="email" type="email" class="form-control mb-3" placeholder="Email" required>
        <input name="password" type="password" class="form-control mb-3" placeholder="Password" required>
        <button class="btn btn-primary w-100">Register</button>
    </form>
    <p class="mt-3 text-center">Already have an account? <a href="login1.php">Login</a></p>
</div>

<button id="backButton" onclick="goBack()">🔙 Back</button>
<script>
    function goBack() {
        window.history.back();
    }
</script>
</body>
</html>
