<?php
// Database connection
$host = "localhost";
$username = "root"; // Change if needed
$password = "";     // Change if needed
$dbname = "bank";

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, name, email, balance FROM customers";
$result = $conn->query($sql);

$users = [];
$userNames = [];
$userBalances = [];

while ($row = $result->fetch_assoc()) {
    $users[] = $row;
    $userNames[] = $row['name'];
    $userBalances[] = $row['balance'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>All Users & Balances</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f0f2f5;
        }
        h2 {
            text-align: center;
            margin: 30px 0;
            font-weight: 700;
        }
        .table td, .table th {
            vertical-align: middle;
        }
        footer {
            background-color: #343a40;
            color: white;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand fw-bold" href="#">TitanTrust Bank</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>

<!-- Page Header -->
<h2>All Users and Account Balances</h2>

<!-- Users Table -->
<div class="container mb-5">
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover text-center shadow-sm">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Balance (₹)</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($users)): ?>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td><?= $user['id'] ?></td>
                            <td><?= htmlspecialchars($user['name']) ?></td>
                            <td><?= htmlspecialchars($user['email']) ?></td>
                            <td class="text-end"><?= number_format($user['balance'], 2) ?></td>
                            <td>
                                <a class="btn btn-primary btn-sm" href="history.php?id=<?= $user['id'] ?>">View Transactions</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="5">No users found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Chart Section -->
<div class="container mb-5">
    <h4 class="text-center mb-4">Graphical Representation of User Balances</h4>
    <div class="text-center mb-3">
        <label for="chartType" class="form-label">Select Chart Type:</label>
        <select id="chartType" class="form-select w-50 mx-auto">
            <option value="bar" selected>Bar</option>
            <option value="pie">Pie</option>
            <option value="line">Line</option>
            <option value="doughnut">Doughnut</option>
        </select>
    </div>
    <canvas id="balanceChart" height="100"></canvas>
</div>

<!-- Footer -->
<footer class="text-center py-4">
    <div class="container">
        <small>&copy; 2025 TitanTrust Bank. All rights reserved.</small><br>
        <small>Made with ❤️ for The Sparks Foundation</small>
    </div>
</footer>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const userNames = <?= json_encode($userNames); ?>;
    const userBalances = <?= json_encode($userBalances); ?>;

    const ctx = document.getElementById('balanceChart').getContext('2d');
    let chart;

    function generateColors(count) {
        const colors = [];
        for (let i = 0; i < count; i++) {
            const hue = Math.floor(Math.random() * 360);
            colors.push(`hsl(${hue}, 70%, 60%)`);
        }
        return colors;
    }

    function renderChart(type) {
        if (chart) chart.destroy();
        chart = new Chart(ctx, {
            type: type,
            data: {
                labels: userNames,
                datasets: [{
                    label: 'Balance (₹)',
                    data: userBalances,
                    backgroundColor: generateColors(userNames.length),
                    borderColor: 'rgba(0, 0, 0, 0.1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: type !== 'bar' && type !== 'line'
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return '₹' + context.parsed.toLocaleString();
                            }
                        }
                    }
                },
                scales: (type === 'bar' || type === 'line') ? {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Balance in ₹'
                        }
                    }
                } : {}
            }
        });
    }

    renderChart('bar');

    document.getElementById('chartType').addEventListener('change', function () {
        renderChart(this.value);
    });
</script>
<style>
    #backButton {
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 10px 15px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
      transition: background-color 0.3s;
    }

    #backButton:hover {
      background-color: #45a049;
    }
  </style>
</head>
<body>

  <button id="backButton" onclick="goBack()">🔙 Back</button>

  <script>
    function goBack() {
      window.history.back();
    }
  </script>

</body>
</html>
<?php $conn->close(); ?>
