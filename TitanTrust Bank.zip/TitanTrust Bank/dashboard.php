<?php
// Connect to database
$conn = new mysqli("localhost", "root", "", "bank");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data
$userCountQuery = "SELECT COUNT(*) AS total_users FROM customers";
$transactionCountQuery = "SELECT COUNT(*) AS total_transactions FROM transactions";
$totalBalanceQuery = "SELECT SUM(balance) AS total_balance FROM customers";

$userResult = $conn->query($userCountQuery)->fetch_assoc();
$transactionResult = $conn->query($transactionCountQuery)->fetch_assoc();
$balanceResult = $conn->query($totalBalanceQuery)->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard - TitanTrust Bank</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f4f6f8;
      font-family: 'Segoe UI', sans-serif;
    }
    .navbar {
      margin-bottom: 20px;
    }
    .card {
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    .dashboard-header {
      margin-bottom: 30px;
    }
    .sidebar a {
      color: #ddd;
      text-decoration: none;
      display: block;
      margin: 10px 0;
    }
    .sidebar a:hover {
      color: #fff;
      text-decoration: underline;
    }
    .float-login {
      position: fixed;
      bottom: 20px;
      right: 20px;
      background-color: #0d6efd;
      color: white;
      border-radius: 50%;
      width: 50px;
      height: 50px;
      text-align: center;
      font-size: 24px;
      line-height: 50px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
      cursor: pointer;
    }
    @media (max-width: 768px) {
      .sidebar {
        display: none;
      }
    }
  </style>
</head>
<body>

  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark px-4">
    <a class="navbar-brand" href="#">TitanTrust Bank</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Actions</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="money.php">Money Transfer</a></li>
            <li><a class="dropdown-item" href="history.php">Transaction History</a></li>
            <li><a class="dropdown-item" href="users.php">Users</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="index.html">Logout</a>
        </li>
      </ul>
    </div>
  </nav>

  <!-- Main Content -->
  <div class="container">
    <h3 class="dashboard-header">Welcome, Admin</h3>

    <div class="row g-4">
      <div class="col-md-4">
        <div class="card p-3">
          <h5>Total Users</h5>
          <p class="display-6"><?= $userResult['total_users'] ?></p>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card p-3">
          <h5>Total Transactions</h5>
          <p class="display-6"><?= $transactionResult['total_transactions'] ?></p>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card p-3">
          <h5>Total Money in Bank</h5>
          <p class="display-6">₹<?= number_format($balanceResult['total_balance'], 2) ?></p>
        </div>
      </div>

      <div class="col-md-6">
        <div class="card p-3">
          <h5>Loan Applications Overview</h5>
          <ul>
            <li>Application #1024 - ₹2,00,000 - <strong>Approved</strong></li>
            <li>Application #1025 - ₹5,00,000 - <strong>Pending</strong></li>
            <li>Application #1026 - ₹1,50,000 - <strong>Rejected</strong></li>
          </ul>
        </div>
      </div>

      <div class="col-md-6">
        <div class="card p-3">
          <h5>Notifications</h5>
          <ul>
            <li>New security update available</li>
            <li>Monthly report ready</li>
            <li>Server backup completed</li>
          </ul>
        </div>
      </div>
    </div>

    <!-- Dynamic News Section -->
    <div class="card mt-4 p-3">
      <h5>Latest News & Updates</h5>
      <ul id="newsList" class="mb-0"></ul>
    </div>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <!-- Dynamic News Script -->
  <script>
    const newsUpdates = [
      { date: 'April 1', message: 'New loan policies introduced for SMEs.' },
      { date: 'April 3', message: 'TitanTrust Bank celebrates its 10th anniversary!' },
      { date: 'April 4', message: 'Security features improved for online banking.' },
      { date: 'April 5', message: 'Mobile app update released with new dashboard features.' }
    ];

    const newsList = document.getElementById('newsList');
    newsUpdates.forEach(update => {
      const li = document.createElement('li');
      li.innerHTML = `<strong>${update.date}:</strong> ${update.message}`;
      newsList.appendChild(li);
    });
  </script><style>
    #backButton {
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 10px 15px;
      background-color: #4CAF50;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
      box-shadow: 0 4px 8px rgba(0,0,0,0.2);
      transition: background-color 0.3s;
    }

    #backButton:hover {
      background-color: #45a049;
    }
  </style>
</head>
<body>

  <button id="backButton" onclick="goBack()">🔙 Back</button>

  <script>
    function goBack() {
      window.history.back();
    }
  </script>


</body>
</html>

<?php $conn->close(); ?>
